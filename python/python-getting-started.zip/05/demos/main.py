from hs_student import *

james = HighSchoolStudent("james")
print(james.get_name_capitalize())