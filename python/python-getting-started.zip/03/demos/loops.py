student_names = ["James", "Katarina", "Jessica", "Mark", "Bort", "Frank Grimes", "Max Power"]

for name in student_names:
	if name == "Bort":
		continue
		print("Found him! " + name)
	print("Currently testing " + name)
