﻿(function (module) {
    
    module.value("Physics", Physics);

}(angular.module("integration")));
    