﻿(function (module) {

    var oauth = function ($http, formEncode, currentUser) {
        
        return {
        };
    };

    module.factory("oauth", oauth);

}(angular.module("common")));