﻿(function(module) {
   
    var currentUser = function(localStorage){
        
        return {
        };
    };

    module.factory("currentUser", currentUser);

}(angular.module("common")));