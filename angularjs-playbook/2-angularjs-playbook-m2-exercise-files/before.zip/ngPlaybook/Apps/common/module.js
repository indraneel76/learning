﻿(function() {

    var module = angular.module("common", []);

}());