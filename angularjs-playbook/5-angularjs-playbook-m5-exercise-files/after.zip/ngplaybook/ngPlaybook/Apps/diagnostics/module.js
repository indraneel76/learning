﻿(function() {

    var module = angular.module("diagnostics", ["common"]);

}());