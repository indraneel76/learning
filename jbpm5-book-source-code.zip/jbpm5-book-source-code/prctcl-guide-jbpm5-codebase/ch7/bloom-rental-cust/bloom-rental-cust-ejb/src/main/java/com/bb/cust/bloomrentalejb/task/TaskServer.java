package com.bb.cust.bloomrentalejb.task;

public interface TaskServer {
	public void start();

	public void stop();
}
