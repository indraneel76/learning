package com.bb.cust.bloomrentalejb.task;

public interface TaskServer {
	public void start() throws Exception;

	public void stop() throws Exception ;

}
