package com.bb.bloomrentalejb.task;

public interface TaskServer {
	public void start();

	public void stop();
}
